package exercise4_1;


public interface BirthdayFactory {
    Birthday getBirthday(int year, Birthday.Month month, int day);
}
