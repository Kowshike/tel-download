package BDPDemo;
//Step1: Create an Interface Item representing food items
public interface Item 
{
	public String name();
	public Packing packing();
	public float price();
}
