package BDPDemo;
//Step1: Create an interface Packing representing Packaging
public interface Packing 
{
	public String pack();
}
